import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'

import '@/styles/fonts.css'
import '@/styles/variables.css'
import '@/styles/base.css'
import '@/styles/page.css'

import { App } from './app/App'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>
)